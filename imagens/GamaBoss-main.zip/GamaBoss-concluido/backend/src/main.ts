import App from "./infra/App";

const instanceOf = new App();

// instanceOf.setup({port: 8080, test: true });

instanceOf.setup({port: 8080 });

