export const linksNav = [
  { name: "Entrar/Cadastrar", redirect: "/login" },
  { name: "Perfil pet", redirect: "/perfil" },
  { name: "Meu Plano", redirect: "/meu-plano" },
];

export const linksNavDesktop = [
  { name: "Perfil pet", redirect: "/perfil" },
  { name: "Meu plano", redirect: "/meu-plano" },
  { name: "Entrar/Cadastrar", redirect: "/login" },
];
