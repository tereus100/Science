import { images } from "../../assets";

export const mockPet = {
  img: images.petAvatar,
  name: "Tobias",
  age: 5 ,
  weight: 8,
  dono: "Alessandra"
}