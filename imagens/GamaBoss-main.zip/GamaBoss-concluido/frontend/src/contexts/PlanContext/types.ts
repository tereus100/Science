export interface IPlanContext {
  checked0: () => void;
  setChecked0: () => void;
  checked1: () => void;
  setChecked1: () => void;
  checked2: () => void;
  setChecked2: () => void;
  checked3: () => void;
  setChecked3: () => void;
  checked4: () => void;
  setChecked4: () => void;
  checked5: () => void;
  setChecked5: () => void;
  checked6: () => void;
  setChecked6: () => void;
  checked7: () => void;
  setChecked7: () => void;
}

export interface IPlanProvider {
  children: JSX.Element;
}
