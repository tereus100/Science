export const mockVerification = { 
    servico1:"Teleatendimento",
    servico2:"Consulta em domicílio",
    servico3:"Cobertura Nacional",
    servico4:"Procedimentos Cirúrgicos"
}